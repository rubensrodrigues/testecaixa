/**
 * 
 */



function logout(){
	delete sessionStorage.token;
	window.location.replace('/SIALG/login.html');
}



$(document).ready(function(){
	
	if(typeof sessionStorage.token == 'undefined'){
		window.location.replace('/SIALG/login.html');
	}
	
	
});